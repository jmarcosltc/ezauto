package com.ezauto.ezauto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EzAutoApplicationTests {

	@Test
	void contextLoads() {
	}

}
